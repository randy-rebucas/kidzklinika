
Greetings from {{sitename}}

Hi {{dfirstname}}, {{dlastname}} 

We send you this email informing that you have an ongoing appointment this coming {{theDate}} {{theTime}}

Appointment Details
From : {{pfirstname}}, {{plastname}}
Address : {{paddress}} 
Contact : {{pcontact}} 

{{theTitle}}
{{theDescription}}

Link doesn't work? Copy the following link to your browser address bar:
<?php echo site_url(); ?>appointment/verify/{{appointment_token}}

Cheers !
{{sitename}} Team
				