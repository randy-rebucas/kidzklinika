
Greetings from {{sitename}}

Newly register user name: {{username}}

Member Details
License : {{license_key}}
IP : {{last_ip}}
eMail : {{email}} 

Cheers !
{{sitename}} Team
					